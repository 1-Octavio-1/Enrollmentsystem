import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MainFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable studentsTable, coursesTable, enrollmentsTable;
    private JButton addButton, editButton, deleteButton;
    
    public MainFrame() {
        setupFrame();
        createComponents();
        setupLayout();
        addListeners();
    }
    
    private void setupFrame() {
        setTitle("Student Enrollment System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    
    private void createComponents() {
        // Create tabbed pane
        tabbedPane = new JTabbedPane();
        
        // Create tables
        studentsTable = new JTable(new DefaultTableModel(
            new String[]{"ID", "Name", "Email", "Phone"}, 0));
        coursesTable = new JTable(new DefaultTableModel(
            new String[]{"Code", "Name", "Credits", "Instructor"}, 0));
        enrollmentsTable = new JTable(new DefaultTableModel(
            new String[]{"Student ID", "Course Code", "Date", "Status"}, 0));
        
        // Add tables to scroll panes
        tabbedPane.addTab("Students", new JScrollPane(studentsTable));
        tabbedPane.addTab("Courses", new JScrollPane(coursesTable));
        tabbedPane.addTab("Enrollments", new JScrollPane(enrollmentsTable));
        
        // Create buttons
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Create toolbar
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.add(addButton);
        toolBar.add(editButton);
        toolBar.add(deleteButton);
        
        // Add components to frame
        add(toolBar, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
        
        // Add status bar
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        statusBar.add(new JLabel("Ready"));
        add(statusBar, BorderLayout.SOUTH);
    }
    
    private void addListeners() {
        addButton.addActionListener(e -> handleAdd());
        editButton.addActionListener(e -> handleEdit());
        deleteButton.addActionListener(e -> handleDelete());
    }
    
    private void handleAdd() {
        int tab = tabbedPane.getSelectedIndex();
        switch (tab) {
            case 0: addStudent(); break;
            case 1: addCourse(); break;
            case 2: addEnrollment(); break;
        }
    }
    
    private void handleEdit() {
        // TODO: Implement edit functionality
    }
    
    private void handleDelete() {
        // TODO: Implement delete functionality
    }
    
    private void addStudent() {
        // TODO: Implement add student dialog
    }
    
    private void addCourse() {
        // TODO: Implement add course dialog
    }
    
    private void addEnrollment() {
        // TODO: Implement add enrollment dialog
    }
}
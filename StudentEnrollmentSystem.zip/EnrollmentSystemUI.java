import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileWriter;
import java.io.PrintWriter;

public class EnrollmentSystemUI extends JFrame {

    private DefaultTableModel studentModel, courseModel, enrollModel;
    private JTable studentTable, courseTable, enrollTable;

    public EnrollmentSystemUI() {
        setTitle("Student Enrollment System");
        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Students", studentPanel());
        tabs.addTab("Courses", coursePanel());
        tabs.addTab("Enrollments", enrollmentPanel());

        add(tabs);
    }

    private JPanel studentPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        studentModel = new DefaultTableModel(new String[]{"ID", "Name"}, 0);
        studentTable = new JTable(studentModel);

        JPanel top = new JPanel();
        JTextField tfId = new JTextField(10);
        JTextField tfName = new JTextField(12);
        JButton addBtn = new JButton("Add Student");
        JButton delBtn = new JButton("Delete Student");

        top.add(new JLabel("Student ID:")); top.add(tfId);
        top.add(new JLabel("Name:")); top.add(tfName);
        top.add(addBtn);
        top.add(delBtn);

        addBtn.addActionListener(e -> {
            String id = tfId.getText().trim();
            String name = tfName.getText().trim();
            if(id.isEmpty() || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
                return;
            }
            studentModel.addRow(new Object[]{id, name});
            tfId.setText(""); tfName.setText("");
        });

        delBtn.addActionListener(e -> {
            int row = studentTable.getSelectedRow();
            if(row == -1) { JOptionPane.showMessageDialog(this, "Select a student."); return; }
            studentModel.removeRow(row);
        });

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(studentTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel coursePanel() {
        JPanel panel = new JPanel(new BorderLayout());

        courseModel = new DefaultTableModel(new String[]{"Course Code", "Course Name"}, 0);
        courseTable = new JTable(courseModel);

        JPanel top = new JPanel();
        JTextField tfCode = new JTextField(10);
        JTextField tfName = new JTextField(12);
        JButton addBtn = new JButton("Add Course");
        JButton delBtn = new JButton("Delete Course");

        top.add(new JLabel("Code:")); top.add(tfCode);
        top.add(new JLabel("Name:")); top.add(tfName);
        top.add(addBtn);
        top.add(delBtn);

        addBtn.addActionListener(e -> {
            String c = tfCode.getText().trim();
            String n = tfName.getText().trim();
            if(c.isEmpty() || n.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fill all fields."); return;
            }
            courseModel.addRow(new Object[]{c, n});
            tfCode.setText(""); tfName.setText("");
        });

        delBtn.addActionListener(e -> {
            int row = courseTable.getSelectedRow();
            if(row == -1) { JOptionPane.showMessageDialog(this, "Select a course."); return; }
            courseModel.removeRow(row);
        });

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(courseTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel enrollmentPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        enrollModel = new DefaultTableModel(new String[]{"Student ID", "Student Name", "Course Code", "Course Name"}, 0);
        enrollTable = new JTable(enrollModel);

        JPanel top = new JPanel();
        JButton enrollBtn = new JButton("Enroll Student in Course");
        JButton dropBtn = new JButton("Drop Student from Course");
        JButton exportBtn = new JButton("Export Enrollments to CSV");

        top.add(enrollBtn);
        top.add(dropBtn);
        top.add(exportBtn);

        enrollBtn.addActionListener(e -> enrollStudent());
        dropBtn.addActionListener(e -> dropEnrollment());
        exportBtn.addActionListener(e -> exportCSV());

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(enrollTable), BorderLayout.CENTER);
        return panel;
    }

    private void enrollStudent() {
        int sRow = studentTable.getSelectedRow();
        int cRow = courseTable.getSelectedRow();

        if(sRow == -1 || cRow == -1) {
            JOptionPane.showMessageDialog(this, "Select both student AND course.");
            return;
        }

        String sid = studentModel.getValueAt(sRow, 0).toString();
        String sname = studentModel.getValueAt(sRow, 1).toString();
        String ccode = courseModel.getValueAt(cRow, 0).toString();
        String cname = courseModel.getValueAt(cRow, 1).toString();

        enrollModel.addRow(new Object[]{sid, sname, ccode, cname});
    }

    private void dropEnrollment() {
        int row = enrollTable.getSelectedRow();
        if(row == -1) {
            JOptionPane.showMessageDialog(this, "Select enrollment to drop.");
            return;
        }
        enrollModel.removeRow(row);
    }

    private void exportCSV() {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("enrollments.csv"));
            for(int i=0; i<enrollModel.getRowCount(); i++) {
                pw.println(
                    enrollModel.getValueAt(i,0)+","+
                    enrollModel.getValueAt(i,1)+","+
                    enrollModel.getValueAt(i,2)+","+
                    enrollModel.getValueAt(i,3)
                );
            }
            pw.close();
            JOptionPane.showMessageDialog(this, "Export successful: enrollments.csv");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Export failed.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EnrollmentSystemUI().setVisible(true));
    }
}
